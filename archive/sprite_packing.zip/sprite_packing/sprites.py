
def compute_sprite_positions(display, sprites):

    ### YOUR CODE HERE ###
    ### (below is just for example) ###
    return [(0,0), (6, 6)], sprites


def render(display, sprites):

    positions, sprites = compute_sprite_positions(display, sprites)

    import numpy as np
    import string
    import random


    ## Create the display array
    out = np.empty(display, dtype=str)
    ## Fill with .
    out[:] = "."
    ## For each sprite, get its position and size, and fill in the array with a 
    ## randomly selected character
    for pos, sprite in zip(positions, sprites):
        x_start, y_start = pos
        x_end, y_end = x_start + sprite[0], y_start + sprite[1]
        out[x_start:x_end, y_start:y_end] = random.choice(string.ascii_letters)

    out = out.T ## Transpose so width and height are correct per problem definition
    
    ## Use prettytable to make nice ASCII table
    from prettytable import PrettyTable, FRAME
    p = PrettyTable()
    for row in out:
        p.add_row(row)
    print(p.get_string(header=False, border=True, vrules=FRAME))



if __name__ == "__main__":


    import re
    import argparse

    parser = argparse.ArgumentParser(description='Sprite Packing')
    parser.add_argument('inp_file', type=str)
    args = parser.parse_args()


    with open(args.inp_file, 'r') as f:
        lines = f.readlines()

    get_display = False
    get_sprites = False

    sprites = list()
    for line in lines:

        if line == "\n": 
            continue ## Allow whitespace

        ## Record 
        if get_display:
            display = eval(line)
            get_display = False
        if get_sprites:
            sprites.append(eval(line))

        ## Toggle recording
        if line.startswith("Display:"):
            get_display = True

        if line.startswith("Sprites:"):
            get_sprites = True

    render(display, sprites)